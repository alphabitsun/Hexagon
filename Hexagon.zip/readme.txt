2:02 PM 4/24/2013
Tim Whiteaker

Contains script, toolbox, and layer file for creating a hexagon tessellation for a study area.  Also includes a map and geodatabase with example data.